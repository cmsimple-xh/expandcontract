<?php

$plugin_tx['expandcontract']['close']="Schließen";
$plugin_tx['expandcontract']['menu_main']="Über";
$plugin_tx['expandcontract']['plugin_call']="Pluginaufruf";
$plugin_tx['expandcontract']['link_hidden_subpages']="Erzeugt Expand-Links zu allen verstecken Unterseiten. <br>Entweder (entprechend der Konfig) als mehrere Buttons nebeneinander in einer Zeile oder als Links in jeweils eigenem Absatz untereinander.";
$plugin_tx['expandcontract']['link_single_page']="Erzeugt einen Expand-Link mit angegebenem \"Linktext\" zur Seite \"page X\". <br>Kann innerhalb einer Zeile stehen in einem als &lt;div>-definierten Absatz oder als letztes Wort in einem Absatz.";
$plugin_tx['expandcontract']['link_multiple_pages']="Erzeugt Expand-Links zu den Seiten \"page1\", \"page2\", \"page3\", \"page4\" .";
$plugin_tx['expandcontract']['cf_show_headings']="Ob die Überschrift der verlinkten Seiten im expandierten Bereich erscheint oder nicht.<br />(Alternativ als dritten Parameter eingeben.)";
$plugin_tx['expandcontract']['cf_show_close_button']="Ob eine 'Schließen'-Schaltfläche am Ende des expandierten Berechs erscheint. <br />(Alternativ als vierten Parameter eingeben.)";
$plugin_tx['expandcontract']['cf_max_height']="Um die Höhe des expandierten Bereichs zu begrenzen, hier die Maximalhöhe eintragen, z.B. 15em.<br />(Alternativ als fünften Parameter eingeben.)";
$plugin_tx['expandcontract']['cf_auto-close']="Nach Ankreuzen: Wenn man ein Expandcontract öffnet, werden andere automatisch geschlossen";
$plugin_tx['expandcontract']['text_update_successful']="Expandcontract wurde erfolgreich auf Version %s aktualisiert.";
$plugin_tx['expandcontract']['cf_use_inline_buttons']="Wenn angeklickt, werden Buttons verwandt, die sich in einer Zeile anordnen, wenn nicht angeklickt, sehen Expand-Links wie normale Links aus, die sich untereinander anordnen. <br />(Alternativ als sechsten Parameter eingeben.)";
?>
