<?php

$plugin_tx['expandcontract']['close']="Zatvoriť";
$plugin_tx['expandcontract']['menu_main']="O plugine";
$plugin_tx['expandcontract']['plugin_call']="Príkaz";
$plugin_tx['expandcontract']['link_hidden_subpages']="Vytvára rozbaľovací odkaz na všetky podradené ukryté stránky. Pre každý samostatný odkaz bude vytvorený samostatný odstavec.";
$plugin_tx['expandcontract']['link_single_page']="Vytvorí rozbaľovací odkaz na stránku \"X\" Zobrazením textového odkazu. Môže sa použiť ako formátovaný odkaz použitý napr. v &lt;div> alebo na konci obyčajného odstavca.";
$plugin_tx['expandcontract']['cf_show_headings']="Má sa zobraziť nadpis odkazovanej stránky?";
$plugin_tx['expandcontract']['cf_show_close_button']="Má sa zobraziť tlačidlo prep zatvorenie zobrazenenj stránky?";
$plugin_tx['expandcontract']['cf_max_height']="Nastavenie max. výšky rozbaľovanej oblasti, uveďte maximálnu výšku napr. 15em.";
$plugin_tx['expandcontract']['cf_auto-close']="Zaškrtnuté znamená, že otvorením odkazu sa všetky predchádzajúce otvorené odkazy automaticky zatvoria.";

?>