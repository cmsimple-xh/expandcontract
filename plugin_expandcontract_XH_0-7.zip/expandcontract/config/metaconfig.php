<?php

$plugin_mcf['expandcontract']['auto-close']="bool";
$plugin_mcf['expandcontract']['use_inline_buttons']="bool";
$plugin_mcf['expandcontract']['show_headings']="bool";
$plugin_mcf['expandcontract']['show_close_button']="bool";
$plugin_mcf['expandcontract']['version']="hidden";

?>
